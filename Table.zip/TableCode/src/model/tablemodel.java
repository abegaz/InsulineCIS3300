package model;

public class tablemodel {
	
	private String patientID;
	private String InsulinID;
	private String FirstName;
	private String LastName;
	private String DiabeticType;
	
	
	public tablemodel(String patientID) {
		super();
		this.patientID = patientID;
	}
	
	
	public String getPatientID() {
		return patientID;
	}
	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getDiabeticType() {
		return DiabeticType;
	}
	public void setDiabeticType(String diabeticType) {
		DiabeticType = diabeticType;
	}
	public String getInsulinID() {
		return InsulinID;
	}
	public void setInsulinID(String insulinID) {
		InsulinID = insulinID;
	}
	

}
