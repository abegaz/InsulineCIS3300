package application;

import java.sql.Connection;

public class SampleController {
			
	
} 
